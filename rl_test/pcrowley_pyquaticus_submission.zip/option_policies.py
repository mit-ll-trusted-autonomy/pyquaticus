from config import ACTIONS
from trained_nn_policy import Trained_DQN_Policy


##################### DO NOT MODIFY ORDER! ########################
###################################################################
options = [
    "pickup",
    "avoid",
    "retreat",
    "shield",
    "guard",
    "tag",
    "no-op"
]

option_idx_map = {option: i for i, option in enumerate(options)}
###################################################################




#################### No-Op Policy Class ###########################
###################################################################
class NoOpPolicy:
    def __init__(self):
        self.no_op_action = ACTIONS.index([0., 0.])
    def compute_action(self, obs):
        return self.no_op_action
##################################################################




############## Define Dictionary of Option Policies ##############
##################################################################
option_policies = {
    option_idx_map[option]: Trained_DQN_Policy(option + '.pt', device='cpu') for option in options if option != "no-op"
}

option_policies[option_idx_map["no-op"]] = NoOpPolicy()
##################################################################