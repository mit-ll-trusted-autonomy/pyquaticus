import copy
import numpy as np
from solution import solution

policy = solution()

for i in range(100):
    test_obs_numpy = np.random.rand(41)
    test_obs_list = list(copy.deepcopy(test_obs_numpy))
    print("Numpy:", policy.compute_action(0, test_obs_numpy, None))
    print("List:", policy.compute_action(0, test_obs_list, None))