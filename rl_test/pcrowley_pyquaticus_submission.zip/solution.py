import numpy as np
from option_policies import option_policies
import os
from trained_nn_policy import Trained_DQN_Policy
#Need an added import for codalab competition submission?
#Post an issue to the github and we will work to get it added into the system!


#YOUR CODE HERE

#Load in your trained model and return the corresponding agent action based on the information provided in step()
class solution:
	#Add Variables required for solution
	
    def __init__(self):
		#Load in policy or anything else you want to load/do here
        #NOTE: You can only load from files that are in the same directory as the solution.py or a subdirectory
        self.option_policies = option_policies #checkpoint 1600 of reward_v1_hybrid_init
        self.policy_over_options = Trained_DQN_Policy('ctf.pt', device='cpu')

	#Given an observation return a valid action agent_id is agent that needs an action, observation space is the current normalized observation space for the specific agent
    def compute_action(self,agent_id:int, observation_normalized:list, observation:dict):
        option = self.policy_over_options.compute_action(observation_normalized)
        return self.option_policies[option].compute_action(observation_normalized)

#END OF CODE SECTION
