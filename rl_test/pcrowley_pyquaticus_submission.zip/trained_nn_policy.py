import torch as T

class Trained_DQN_Policy:
    """
    class for serving a DQN policy
    """
    def __init__(self, model_path, device='cpu'):
        self.device = device
        self.model = T.jit.load(model_path, map_location=device)
        self.model.to(self.model.device)
        self.model.eval()

    def inference(self, x):
        x = T.tensor(x, dtype=T.float).to(self.model.device)

        with T.no_grad():
            return self.model(x)

    def compute_action(self, obs):
        Q = self.inference(obs)

        return T.argmax(Q).item()