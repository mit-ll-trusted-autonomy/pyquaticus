import argparse
import gymnasium as gym
import numpy as np
import pygame
from pygame import KEYDOWN, QUIT, K_ESCAPE
import sys
import time
import pyquaticus
from pyquaticus.structs import Team
from pyquaticus import pyquaticus_v0
import os
from pyquaticus.base_policies.base import BaseAgentPolicy
from pyquaticus.base_policies.base_attack import BaseAttacker
from pyquaticus.base_policies.base_defend import BaseDefender
from pyquaticus.base_policies.base_combined import Heuristic_CTF_Agent
from ray.rllib.algorithms.ppo import PPOConfig
from ray.tune.registry import register_env
from ray.rllib.env.wrappers.pettingzoo_env import ParallelPettingZooEnv
from ray.rllib.policy.policy import Policy
#Need an added import for codalab competition submission?
#Post an issue to the github and we will work to get it added into the system!


#YOUR CODE HERE

#Load in your trained model and return the corresponding agent action based on the information provided in step()
class solution:
	#Add Variables required for solution
	
    def __init__(self, team, normalizer=None):
		#Load in policy or anything else you want to load/do here
        #NOTE: You can only load from files that are in the same directory as the solution.py or a subdirectory
        self.normalizer = normalizer# This is used to unnormalize the observation space if needed for your solution
        self.team = team
        
        #Load in learned policies
        self.policy_one = Policy.from_checkpoint(os.path.dirname(os.path.realpath(__file__))+ '/checkpoint_000006/policies/agent-0-policy/')
        self.policy_two = Policy.from_checkpoint(os.path.dirname(os.path.realpath(__file__))+ '/checkpoint_000006/policies/agent-1-policy/')

	#Given an observation return a valid action agent_id is agent that needs an action, observation space is the current normalized observation space for the specific agent
    def compute_action(self,agent_id:int, observation:dict):
		#If making a heuristic based agent you might want the observation space unnormalized:
		#observation = env.agent_obs_normalizer.unnormalized(observation)
        #See how the base policies are constructed for more information on creating a heuristic based agent
        if agent_id == 0 or agent_id == 2:
            return self.policy_one.compute_single_action(observation[0])[0]
        else:
            return self.policy_two.compute_single_action(observation[1])[0]

#END OF CODE SECTION
