How to zip your submission

zip outzip.zip -r checkpoints gen_config.py solution.py

**Only change observation parameters in the gen_config.py to match what you used in training. Changing other settings will result in disqualification of that submission (You can resubmit with a new config file later)**
